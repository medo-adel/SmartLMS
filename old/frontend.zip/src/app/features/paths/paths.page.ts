import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IonContent, IonButton } from '@ionic/angular';
import { LearningService } from '../../core/services/learning.service';
import { PathDetail } from '../../core/models/learning';
import { TranslatePipe } from '../../core/pipes/translate.pipe';

@Component({ selector: 'app-paths', imports: [RouterLink, IonContent, IonButton, TranslatePipe], templateUrl: './paths.page.html', styleUrl: './paths.page.scss' })
export class PathsPage implements OnInit {
  private readonly api = inject(LearningService);
  readonly paths = signal<PathDetail[] | null>(null);
  readonly failed = signal(false);
  readonly done = signal<string | null>(null);
  ngOnInit(): void { void this.load(); }
  async load(): Promise<void> {
    this.failed.set(false);
    try {
      const list = await this.api.paths();
      this.paths.set(await Promise.all(list.map((p) => this.api.path(p.id))));
    } catch { this.failed.set(true); }
  }
  async enroll(p: PathDetail): Promise<void> {
    try { await this.api.enrollPath(p.id); this.done.set(p.id); } catch { /* toast */ }
  }
}
