import { Component, ElementRef, HostListener, OnDestroy, OnInit, inject, signal, viewChild } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { IonContent, IonButton, IonSpinner } from '@ionic/angular';
import { LearningService } from '../../core/services/learning.service';
import { AuthService } from '../../core/services/auth.service';
import { CourseDetail, InteractiveQuiz, Lesson, LessonOutline } from '../../core/models/learning';
import { TranslatePipe } from '../../core/pipes/translate.pipe';
import { AiTutorDrawerComponent } from '../ai/ai-tutor-drawer.component';
import { LessonExtrasComponent } from './lesson-extras.component';
import { PrivacyService } from '../../core/services/privacy.service';
import { LessonSlide } from '../../core/models/learning';
import { OfflineEntry, OfflineService } from '../../core/services/offline.service';
import { ProgressSyncService } from '../../core/services/progress-sync.service';
import { NetworkService } from '../../core/services/network.service';

/**
 * Lesson player. Media is fetched from the protected stream endpoint with the bearer token and played from a blob URL.
 * Dynamic watermark and privacy screen are web-page level deterrents only (see the on-screen note).
 */
@Component({ selector: 'app-player', imports: [RouterLink, IonContent, IonButton, IonSpinner, TranslatePipe, AiTutorDrawerComponent, LessonExtrasComponent], templateUrl: './player.page.html', styleUrl: './player.page.scss' })
export class PlayerPage implements OnInit, OnDestroy {
  private readonly api = inject(LearningService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  readonly auth = inject(AuthService);
  private readonly privacy = inject(PrivacyService);
  readonly offline = inject(OfflineService);
  private readonly sync = inject(ProgressSyncService);
  readonly net = inject(NetworkService);
  readonly offlineMode = signal(false);
  readonly dlMsg = signal('');
  readonly slides = signal<LessonSlide[]>([]);
  readonly slideIx = signal(0);
  readonly unlockMsg = signal('');
  readonly canUnlock = signal(false);
  readonly nowFn = (): number => this.media()?.nativeElement.currentTime ?? 0;
  private readonly sanitizer = inject(DomSanitizer);
  readonly safeUrl = signal<SafeResourceUrl | null>(null);
  readonly media = viewChild<ElementRef<HTMLMediaElement>>('media');
  readonly lesson = signal<Lesson | null>(null);
  readonly course = signal<CourseDetail | null>(null);
  readonly mediaUrl = signal<string | null>(null);
  readonly failed = signal(false);
  readonly locked = signal(false);
  readonly hidden = signal(false);
  readonly drawer = signal(false);
  readonly wm = signal({ x: 10, y: 10, text: '' });
  readonly quiz = signal<InteractiveQuiz | null>(null);
  readonly quizMsg = signal('');
  speed = 1;
  private quizzes: InteractiveQuiz[] = [];
  private answered = new Set<string>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private wmTimer: ReturnType<typeof setInterval> | null = null;
  private lastSaved = 0;
  private url: string | null = null;

  get courseId(): string { return this.route.snapshot.paramMap.get('courseId') ?? ''; }
  get lessonId(): string { return this.route.snapshot.paramMap.get('lessonId') ?? ''; }

  ngOnInit(): void {
    void this.privacy.enable(); // native screenshot and recording protection while a lesson is open
    void this.offline.load().then(() => this.load());
    this.moveWatermark();
    this.wmTimer = setInterval(() => this.moveWatermark(), 7000); // the mark keeps moving so it cannot be cropped out of one corner
  }
  ngOnDestroy(): void {
    if (this.timer) clearInterval(this.timer);
    if (this.wmTimer) clearInterval(this.wmTimer);
    if (this.url) URL.revokeObjectURL(this.url);
    void this.flush(false);
    void this.privacy.disable();
  }
  private moveWatermark(): void {
    const u = this.auth.user();
    this.wm.set({ x: 5 + Math.random() * 55, y: 8 + Math.random() * 70, text: `${u?.fullName ?? ''} · ${u?.email ?? ''} · ${new Date().toLocaleString()}` });
  }

  async load(): Promise<void> {
    this.failed.set(false); this.locked.set(false);
    this.offlineMode.set(false);
    try {
      const saved = this.offline.entry(this.lessonId);
      let lesson: Lesson, course: CourseDetail;
      if (!this.net.online() && saved) { ({ lesson, course } = saved); await this.useOffline(saved); }
      else {
        try { [lesson, course] = await Promise.all([this.api.lesson(this.lessonId), this.api.course(this.courseId)]); }
        catch (e) {
          if ((e as { status?: number }).status !== 0 || !saved) throw e;
          ({ lesson, course } = saved); await this.useOffline(saved); // the network dropped: fall back to the downloaded copy
        }
        if (!this.offlineMode() && ['Video', 'Audio', 'Pdf'].includes(lesson.lessonType)) this.setMedia(await this.api.streamBlob(this.lessonId));
      }
      this.lesson.set(lesson); this.course.set(course);
      if (lesson.lessonType === 'InteractiveSlides') { this.slides.set(await this.api.slides(this.lessonId).catch(() => [])); this.slideIx.set(0); }
      if (lesson.lessonType === 'Video') { this.quizzes = this.offlineMode() ? [] : await this.api.interactiveQuizzes(this.lessonId).catch(() => []); }
      if (!this.timer) this.timer = setInterval(() => void this.flush(false), 15000);
    } catch (e) {
      const status = (e as { status?: number }).status;
      if (status === 402 || status === 403) { this.locked.set(true); this.canUnlock.set(true); } else this.failed.set(true);
    }
  }

  private setMedia(blob: Blob): void {
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = URL.createObjectURL(blob); this.mediaUrl.set(this.url); this.safeUrl.set(this.sanitizer.bypassSecurityTrustResourceUrl(this.url));
  }
  private async useOffline(e: OfflineEntry): Promise<void> {
    this.setMedia(await this.offline.open(e.lessonId)); this.offlineMode.set(true);
  }
  async download(): Promise<void> {
    const l = this.lesson(), c = this.course(); if (!l || !c) return;
    this.dlMsg.set('');
    try { await this.offline.download(l, c); this.dlMsg.set('dl.done'); } catch (e) { this.dlMsg.set(`dl.err.${(e as Error).message}`); }
  }
  async removeDownload(): Promise<void> { await this.offline.remove(this.lessonId); this.dlMsg.set('dl.removed'); }
  canDownload(): boolean { return ['Video', 'Audio', 'Pdf'].includes(this.lesson()?.lessonType ?? ''); }

  /** Saves progress: position, seconds watched since the last save, completion flag. */
  private async flush(completed: boolean): Promise<void> {
    const el = this.media()?.nativeElement, l = this.lesson();
    if (!l) return;
    const pos = el ? Math.floor(el.currentTime) : 0;
    const delta = el && !el.paused ? 15 : Math.max(0, pos - this.lastSaved);
    await this.sync.record(l.id, pos, Math.min(delta, 60), completed, this.speed); // saved now, or queued on the device and replayed when online
    this.lastSaved = pos;
  }
  /** Pay-per-lesson: charges the wallet through POST /lessons/{id}/unlock. The server refuses lessons that are not sold on their own. */
  async unlock(): Promise<void> {
    try { await this.api.unlockLesson(this.lessonId); this.unlockMsg.set('player.unlocked'); this.canUnlock.set(false); await this.load(); } catch { this.unlockMsg.set('common.error'); }
  }
  slide(): LessonSlide | null { return this.slides()[this.slideIx()] ?? null; }
  go(d: number): void { const n = this.slideIx() + d; if (n >= 0 && n < this.slides().length) this.slideIx.set(n); }
  async complete(): Promise<void> { await this.flush(true); const n = this.next(); if (n) await this.router.navigate(['/app/learn', this.courseId, n.id]); }

  next(): LessonOutline | null {
    const all = (this.course()?.sections ?? []).flatMap((s) => s.lessons);
    const i = all.findIndex((l) => l.id === this.lessonId);
    return i >= 0 && i < all.length - 1 ? all[i + 1] : null;
  }
  onTime(): void {
    const el = this.media()?.nativeElement; if (!el || this.quiz()) return;
    const due = this.quizzes.find((q) => !this.answered.has(q.id) && el.currentTime >= q.timestampSeconds);
    if (due) { el.pause(); this.quiz.set(due); }
  }
  async answerQuiz(optionId: string): Promise<void> {
    const q = this.quiz(); if (!q) return;
    try { await this.api.answerInteractiveQuiz(q.id, { optionId }); this.answered.add(q.id); this.quiz.set(null); void this.media()?.nativeElement.play(); } catch { this.quizMsg.set('common.error'); }
  }
  setSpeed(v: string): void { this.speed = Number(v); const el = this.media()?.nativeElement; if (el) el.playbackRate = this.speed; }
  seek(seconds: number): void { const el = this.media()?.nativeElement; if (el) { el.currentTime = seconds; void el.play(); } }

  // privacy screen: the picture is covered whenever the window or tab loses focus
  @HostListener('window:blur') onBlur(): void { this.hidden.set(true); this.media()?.nativeElement.pause(); }
  @HostListener('window:focus') onFocus(): void { this.hidden.set(false); }
  @HostListener('document:visibilitychange') onVis(): void { this.hidden.set(document.hidden); if (document.hidden) this.media()?.nativeElement.pause(); }
  @HostListener('contextmenu', ['$event']) noMenu(e: Event): void { if (this.mediaUrl()) e.preventDefault(); }
}
