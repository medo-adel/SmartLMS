import { RouterLink } from '@angular/router';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonContent, IonButton } from '@ionic/angular';
import { LearningService } from '../../core/services/learning.service';
import { AiQuizDraft, CourseDetail, Lesson, MyCourse } from '../../core/models/learning';
import { TranslatePipe } from '../../core/pipes/translate.pipe';

/** Instructor course builder: draft courses, sections, lessons, media upload, AI indexing and the AI quiz generator (drafts only). */
@Component({ selector: 'app-builder', imports: [FormsModule, RouterLink, IonContent, IonButton, TranslatePipe], templateUrl: './builder.page.html', styleUrl: './builder.page.scss' })
export class BuilderPage implements OnInit {
  private readonly api = inject(LearningService);
  readonly courses = signal<MyCourse[] | null>(null);
  readonly detail = signal<CourseDetail | null>(null);
  readonly draft = signal<AiQuizDraft | null>(null);
  readonly failed = signal(false);
  readonly busy = signal(false);
  readonly info = signal('');
  title = ''; short = '';
  sectionTitle = '';
  lessonTitle = ''; lessonType = 'Video'; lessonText = ''; lessonUrl = ''; sectionId = '';
  quizLesson = ''; mcq = 5; open = 2; cards = 5;
  selected = '';
  // inline editors
  readonly editSection = signal('');
  readonly editLesson = signal('');
  readonly chapterLesson = signal('');
  readonly confirmDelete = signal('');
  secName = '';
  lesName = ''; lesText = ''; lesUrl = '';
  loadedLesson: Lesson | null = null;
  chapters: { title: string; startSeconds: number }[] = [];
  resTitle = '';
  // pricing and slides
  price = { model: 'Free', amount: 0, currency: 'EGP', days: null as number | null };
  lessonPrice: number | null = null;
  readonly slideLesson = signal('');
  readonly slideRows = signal<{ title: string; body: string; imageUrl: string }[]>([]);

  ngOnInit(): void { void this.load(); }
  async load(): Promise<void> {
    this.failed.set(false);
    try { this.courses.set(await this.api.myCourses()); } catch { this.failed.set(true); }
  }
  async open1(id: string): Promise<void> {
    this.selected = id; this.draft.set(null);
    try { const d = await this.api.course(id); this.detail.set(d); this.price = { model: d.pricingModel, amount: d.price ?? 0, currency: d.currency ?? 'EGP', days: null }; this.sectionId = d.sections[0]?.id ?? ''; } catch { /* toast */ }
  }
  async create(): Promise<void> {
    if (!this.title.trim()) return;
    try { await this.api.createCourse(this.title.trim(), this.short.trim()); this.title = ''; this.short = ''; await this.load(); } catch { /* toast */ }
  }
  async addSection(): Promise<void> {
    if (!this.sectionTitle.trim() || !this.selected) return;
    try { await this.api.addSection(this.selected, this.sectionTitle.trim()); this.sectionTitle = ''; await this.open1(this.selected); } catch { /* toast */ }
  }
  async addLesson(): Promise<void> {
    if (!this.lessonTitle.trim() || !this.sectionId) return;
    try {
      await this.api.addLesson(this.sectionId, this.lessonTitle.trim(), this.lessonType, this.lessonText.trim() || null, this.lessonUrl.trim() || null);
      this.lessonTitle = ''; this.lessonText = ''; this.lessonUrl = ''; await this.open1(this.selected);
    } catch { /* toast */ }
  }
  async upload(lessonId: string, ev: Event): Promise<void> {
    const file = (ev.target as HTMLInputElement).files?.[0]; if (!file) return;
    this.busy.set(true);
    try { await this.api.uploadLessonMedia(lessonId, file); this.info.set('✓'); } catch { /* toast */ }
    this.busy.set(false);
  }
  async index(lessonId: string): Promise<void> { try { await this.api.queueIngest(lessonId); this.info.set('✓'); } catch { /* toast */ } }
  async submitApproval(): Promise<void> { try { await this.api.submitForApproval(this.selected); this.info.set('✓'); await this.load(); } catch { /* toast */ } }
  async makeQuiz(): Promise<void> {
    if (!this.quizLesson) return;
    this.busy.set(true); this.draft.set(null);
    try { this.draft.set(await this.api.generateQuiz(this.quizLesson, this.mcq, this.open, this.cards)); } catch { /* toast */ }
    this.busy.set(false);
  }
  get lessons(): { id: string; title: string }[] { return (this.detail()?.sections ?? []).flatMap((s) => s.lessons.map((l) => ({ id: l.id, title: l.title }))); }

  private async refresh(): Promise<void> { await this.open1(this.selected); }
  startRename(id: string, title: string): void { this.editSection.set(id); this.secName = title; }
  async saveSection(id: string): Promise<void> {
    const sec = this.detail()?.sections.find((x) => x.id === id); if (!sec || !this.secName.trim()) return;
    try { await this.api.updateSection(id, this.secName.trim(), sec.description, sec.sortOrder); this.editSection.set(''); await this.refresh(); } catch { /* toast */ }
  }
  async removeSection(id: string): Promise<void> {
    if (this.confirmDelete() !== id) { this.confirmDelete.set(id); return; }
    this.confirmDelete.set('');
    try { await this.api.deleteSection(id); await this.refresh(); } catch { /* toast */ }
  }
  async removeLesson(id: string): Promise<void> {
    if (this.confirmDelete() !== id) { this.confirmDelete.set(id); return; }
    this.confirmDelete.set('');
    try { await this.api.deleteLesson(id); await this.refresh(); } catch { /* toast */ }
  }
  /** New order after moving the item at index i by delta (-1 up, +1 down); null at the ends. */
  static moved(ids: string[], i: number, delta: number): string[] | null {
    const j = i + delta; if (j < 0 || j >= ids.length) return null;
    const a = [...ids]; [a[i], a[j]] = [a[j], a[i]]; return a;
  }
  async moveSection(i: number, delta: number): Promise<void> {
    const ids = BuilderPage.moved((this.detail()?.sections ?? []).map((x) => x.id), i, delta); if (!ids) return;
    try { await this.api.orderSections(this.selected, ids); await this.refresh(); } catch { /* toast */ }
  }
  async moveLesson(sectionId: string, i: number, delta: number): Promise<void> {
    const sec = this.detail()?.sections.find((x) => x.id === sectionId); if (!sec) return;
    const ids = BuilderPage.moved(sec.lessons.map((x) => x.id), i, delta); if (!ids) return;
    try { await this.api.orderLessons(sectionId, ids); await this.refresh(); } catch { /* toast */ }
  }
  async startEditLesson(id: string): Promise<void> {
    try {
      const l = await this.api.lesson(id); this.loadedLesson = l; this.lessonPrice = null; this.lesName = l.title; this.lesText = l.contentMarkdown ?? ''; this.lesUrl = l.externalUrl ?? ''; this.editLesson.set(id); this.chapterLesson.set('');
    } catch { /* toast */ }
  }
  async saveLesson(sortOrder: number): Promise<void> {
    const l = this.loadedLesson; if (!l || !this.lesName.trim()) return;
    try { await this.api.updateLesson(l.id, l, this.lesName.trim(), this.lesText.trim() || null, this.lesUrl.trim() || null, sortOrder); this.editLesson.set(''); await this.refresh(); } catch { /* toast */ }
  }
  startChapters(id: string): void { this.chapterLesson.set(id); this.editLesson.set(''); this.chapters = [{ title: '', startSeconds: 0 }]; }
  addChapter(): void { this.chapters = [...this.chapters, { title: '', startSeconds: 0 }]; }
  dropChapter(i: number): void { this.chapters = this.chapters.filter((_, k) => k !== i); }
  async saveChapters(): Promise<void> {
    const rows = this.chapters.filter((c) => c.title.trim()).map((c) => ({ title: c.title.trim(), startSeconds: Math.max(0, Math.floor(Number(c.startSeconds) || 0)) })).sort((a, b) => a.startSeconds - b.startSeconds);
    try { await this.api.setChapters(this.chapterLesson(), rows); this.info.set('✓'); this.chapterLesson.set(''); } catch { /* toast */ }
  }
  async savePricing(): Promise<void> {
    try { await this.api.setPricing(this.selected, this.price.model, this.price.model === 'OneTime' ? Number(this.price.amount) : 0, this.price.currency || null, this.price.days ? Number(this.price.days) : null); this.info.set('✓'); await this.refresh(); } catch { /* toast */ }
  }
  async saveLessonPrice(id: string): Promise<void> {
    try { await this.api.setLessonPrice(id, this.lessonPrice && this.lessonPrice > 0 ? Number(this.lessonPrice) : null); this.info.set('✓'); } catch { /* toast */ }
  }
  /** Slides are plain title, text and optional image link; the API stores each slide as JSON and replaces the whole deck on save. */
  async startSlides(id: string): Promise<void> {
    this.slideLesson.set(id); this.editLesson.set(''); this.chapterLesson.set('');
    try { const rows = await this.api.slides(id); this.slideRows.set(rows.length ? rows.map((r) => ({ title: String(r.content.title ?? ''), body: String(r.content.body ?? ''), imageUrl: String(r.content.imageUrl ?? '') })) : [{ title: '', body: '', imageUrl: '' }]); } catch { this.slideRows.set([{ title: '', body: '', imageUrl: '' }]); }
  }
  addSlide(): void { this.slideRows.update((r) => [...r, { title: '', body: '', imageUrl: '' }]); }
  dropSlide(i: number): void { this.slideRows.update((r) => r.filter((_, k) => k !== i)); }
  async saveSlides(): Promise<void> {
    const deck = this.slideRows().filter((r) => r.title.trim() || r.body.trim()).map((r) => ({ title: r.title.trim(), body: r.body.trim(), ...(r.imageUrl.trim().startsWith('https://') ? { imageUrl: r.imageUrl.trim() } : {}) }));
    try { await this.api.setSlides(this.slideLesson(), deck); this.info.set('✓'); this.slideLesson.set(''); } catch { /* toast */ }
  }
  async uploadResource(lessonId: string, ev: Event): Promise<void> {
    const input = ev.target as HTMLInputElement; const file = input.files?.[0]; if (!file) return;
    this.busy.set(true);
    try { await this.api.uploadResource(lessonId, file, this.resTitle.trim() || null, true); this.info.set('✓'); this.resTitle = ''; } catch { /* toast */ }
    input.value = ''; this.busy.set(false);
  }
}
