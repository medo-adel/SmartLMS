import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { IonContent, IonButton } from '@ionic/angular';
import { LearningService } from '../../core/services/learning.service';
import { AffiliateMe, OrderRow } from '../../core/models/learning';
import { TranslatePipe } from '../../core/pipes/translate.pipe';

/** Order history with invoice download, and the affiliate (referral) panel when the user has an affiliate profile. */
@Component({ selector: 'app-orders', imports: [DatePipe, IonContent, IonButton, TranslatePipe], templateUrl: './orders.page.html', styleUrl: './orders.page.scss' })
export class OrdersPage implements OnInit {
  private readonly api = inject(LearningService);
  readonly orders = signal<OrderRow[] | null>(null);
  readonly aff = signal<AffiliateMe | null>(null);
  readonly noAff = signal(false);
  readonly failed = signal(false);
  readonly copied = signal(false);
  ngOnInit(): void { void this.load(); }
  async load(): Promise<void> {
    this.failed.set(false);
    const [o, a] = await Promise.allSettled([this.api.orders(), this.api.affiliate()]);
    if (o.status === 'fulfilled') this.orders.set(o.value.items); else this.failed.set(true);
    if (a.status === 'fulfilled') this.aff.set(a.value); else this.noAff.set(true); // 404 NOT_AN_AFFILIATE is normal
  }
  async invoice(o: OrderRow): Promise<void> {
    try { const blob = await this.api.invoiceBlob(o.id); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `invoice-${o.id}.pdf`; a.click(); URL.revokeObjectURL(a.href); } catch { /* toast */ }
  }
  async copy(a: AffiliateMe): Promise<void> { try { await navigator.clipboard.writeText(a.referralCode); this.copied.set(true); } catch { /* clipboard blocked */ } }
}
