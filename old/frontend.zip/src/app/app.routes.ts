import { Routes } from '@angular/router';
import { authGuard, guestGuard, roleGuard } from './core/guards/guards';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'app/dashboard' },
  { path: 'login', canActivate: [guestGuard], loadComponent: () => import('./features/auth/login/login.page').then((m) => m.LoginPage) },
  { path: 'lock', loadComponent: () => import('./features/auth/lock/lock.page').then((m) => m.LockPage) },
  {
    path: 'app', canActivate: [authGuard], loadComponent: () => import('./features/shell/shell.component').then((m) => m.ShellComponent),
    children: [
      { path: 'dashboard', loadComponent: () => import('./features/dashboard/dashboard.page').then((m) => m.DashboardPage) },
      { path: 'notifications', loadComponent: () => import('./features/notifications/notifications.page').then((m) => m.NotificationsPage) },
      { path: 'profile', loadComponent: () => import('./features/profile/profile.page').then((m) => m.ProfilePage) },
      { path: 'courses', loadComponent: () => import('./features/catalog/catalog.page').then((m) => m.CatalogPage) },
      { path: 'courses/:id', loadComponent: () => import('./features/catalog/course-detail.page').then((m) => m.CourseDetailPage) },
      { path: 'paths', loadComponent: () => import('./features/paths/paths.page').then((m) => m.PathsPage) },
      { path: 'learn/:courseId/:lessonId', loadComponent: () => import('./features/player/player.page').then((m) => m.PlayerPage) },
      { path: 'exam/:examId', loadComponent: () => import('./features/exam/exam.page').then((m) => m.ExamPage) },
      { path: 'cart', canActivate: [roleGuard], data: { roles: ['Student'] }, loadComponent: () => import('./features/cart/cart.page').then((m) => m.CartPage) },
      { path: 'wallet', canActivate: [roleGuard], data: { roles: ['Student'] }, loadComponent: () => import('./features/wallet/wallet.page').then((m) => m.WalletPage) },
      { path: 'ai', canActivate: [roleGuard], data: { roles: ['Student'] }, loadComponent: () => import('./features/ai/ai-studio.page').then((m) => m.AiStudioPage) },
      { path: 'orders', canActivate: [roleGuard], data: { roles: ['Student', 'Instructor'] }, loadComponent: () => import('./features/orders/orders.page').then((m) => m.OrdersPage) },
      { path: 'downloads', canActivate: [roleGuard], data: { roles: ['Student'] }, loadComponent: () => import('./features/downloads/downloads.page').then((m) => m.DownloadsPage) },
      { path: 'monetization', canActivate: [roleGuard], data: { roles: ['TenantAdmin'] }, loadComponent: () => import('./features/monetization/monetization.page').then((m) => m.MonetizationPage) },
      { path: 'payments', canActivate: [roleGuard], data: { roles: ['TenantAdmin'] }, loadComponent: () => import('./features/payments/payments.page').then((m) => m.PaymentsPage) },
      { path: 'assessments', canActivate: [roleGuard], data: { roles: ['Instructor'] }, loadComponent: () => import('./features/authoring/authoring.page').then((m) => m.AuthoringPage) },
      { path: 'build', canActivate: [roleGuard], data: { roles: ['Instructor'] }, loadComponent: () => import('./features/builder/builder.page').then((m) => m.BuilderPage) },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
    ],
  },
  { path: '**', redirectTo: 'app/dashboard' },
];
