import { Injectable, inject, signal, computed } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiResponse } from '../models/api-response';
import { Session, TokenResponse, User, DashboardKind } from '../models/models';
import { StorageService } from './storage.service';
import { DeviceService } from './device.service';
import { TenantService } from './tenant.service';

const KEY = 'session';

/** Which dashboard a set of roles gets. Highest privilege wins. */
export function dashboardFor(roles: readonly string[]): DashboardKind {
  // Mirrors the API: /dashboards/admin = TenantAdmin only, /dashboards/instructor = Instructor only,
  // so SuperAdmin and TeachingAssistant would get 403 there and see the "no dashboard" page instead.
  if (roles.includes('TenantAdmin')) return 'admin';
  if (roles.includes('Instructor')) return 'instructor';
  if (roles.includes('Parent')) return 'parent';
  if (roles.includes('Student')) return 'student';
  return 'none';
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly storage = inject(StorageService);
  private readonly device = inject(DeviceService);
  private readonly tenant = inject(TenantService);
  private readonly _session = signal<Session | null>(null);
  private refreshing: Promise<boolean> | null = null;

  readonly session = this._session.asReadonly();
  readonly user = computed<User | null>(() => this._session()?.user ?? null);
  readonly isAuthenticated = computed(() => this._session() !== null);
  readonly dashboard = computed<DashboardKind>(() => dashboardFor(this._session()?.user.roles ?? []));
  /** False after a cold start with a stored session until the user passes the biometric lock (native only). */
  readonly unlocked = signal(false);

  /** Token for requests. Null while the biometric lock is closed, so a locked app sends nothing. */
  get accessToken(): string | null { return this.unlocked() ? (this._session()?.accessToken ?? null) : null; }
  unlock(): void { this.unlocked.set(true); }
  hasRole(...roles: string[]): boolean { const r = this._session()?.user.roles ?? []; return roles.some((x) => r.includes(x)); }

  async restore(): Promise<void> {
    const s = await this.storage.getJson<Session>(KEY);
    if (s?.accessToken && s.refreshToken) {
      this._session.set(s); this.tenant.adoptTenantId(s.user.tenantId);
      // With biometric unlock on (native), the stored session stays unusable until the OS confirms the user.
      this.unlocked.set(!(Capacitor.isNativePlatform() && (await this.storage.get('biometricEnabled')) === '1'));
    }
  }
  async login(email: string, password: string): Promise<void> {
    const d = await this.device.init();
    const res = await firstValueFrom(this.http.post<ApiResponse<TokenResponse>>(`${environment.apiBaseUrl}/auth/login`, {
      email, password, device: { fingerprint: d.fingerprint, deviceType: d.deviceType, platform: d.platform, deviceName: d.deviceName },
    }));
    if (!res.success || !res.data) throw new Error(res.message ?? 'login failed');
    await this.setSession(res.data);
    await this.tenant.loadBranding();
  }
  /** Single-flight: concurrent 401s share one refresh call so the rotating refresh token is used once. */
  refresh(): Promise<boolean> {
    if (this.refreshing) return this.refreshing;
    this.refreshing = this.doRefresh().finally(() => { this.refreshing = null; });
    return this.refreshing;
  }
  private async doRefresh(): Promise<boolean> {
    const cur = this._session();
    if (!cur) return false;
    try {
      const d = await this.device.init();
      const res = await firstValueFrom(this.http.post<ApiResponse<TokenResponse>>(`${environment.apiBaseUrl}/auth/refresh`,
        { refreshToken: cur.refreshToken, deviceFingerprint: d.fingerprint }));
      if (!res.success || !res.data) throw new Error('refresh rejected');
      await this.setSession(res.data);
      return true;
    } catch { await this.clear(); return false; }
  }
  async logout(): Promise<void> {
    const cur = this._session();
    // /auth/logout requires the bearer token, so revoke on the server first, then clear locally.
    if (cur && this.unlocked()) { try { await firstValueFrom(this.http.post(`${environment.apiBaseUrl}/auth/logout`, { refreshToken: cur.refreshToken })); } catch { /* offline or expired: still sign out locally */ } }
    await this.clear();
  }
  async clear(): Promise<void> { this.unlocked.set(false); this._session.set(null); await this.storage.remove(KEY); }
  private async setSession(t: TokenResponse): Promise<void> {
    this.unlocked.set(true);
    const s: Session = { accessToken: t.accessToken, refreshToken: t.refreshToken, user: t.user };
    this._session.set(s);
    this.tenant.adoptTenantId(t.user.tenantId);
    await this.storage.setJson(KEY, s);
  }
}
