import { WebPlugin } from "./@capacitor_core.js";
// node_modules/@capacitor-community/privacy-screen/dist/esm/web.js
var PrivacyScreenWeb = class extends WebPlugin {
	async enable() {
		throw this.unimplemented("Not implemented on web.");
	}
	async disable() {
		throw this.unimplemented("Not implemented on web.");
	}
};
export { PrivacyScreenWeb };
