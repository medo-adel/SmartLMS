import { registerPlugin } from "./@capacitor_core.js";
// node_modules/@capacitor/device/dist/esm/index.js
var Device = registerPlugin("Device", { web: () => import("./web-hJMUqjsW.js").then((m) => new m.DeviceWeb()) });
export { Device };
