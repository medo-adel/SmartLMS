// node_modules/@ionic/core/components/p-CyKwPay6.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var t = "hydrated";
var n = class {
	constructor() {
		this.m = /* @__PURE__ */ new Map();
	}
	reset(t) {
		this.m = new Map(Object.entries(t));
	}
	get(t, n) {
		const e = this.m.get(t);
		return void 0 !== e ? e : n;
	}
	getBoolean(t, n = !1) {
		const e = this.m.get(t);
		return void 0 === e ? n : "string" == typeof e ? "true" === e : !!e;
	}
	getNumber(t, n) {
		const e = parseFloat(this.m.get(t));
		return isNaN(e) ? void 0 !== n ? n : NaN : e;
	}
	set(t, n) {
		this.m.set(t, n);
	}
};
var e = new n();
var o = (t) => {
	try {
		const n = t.sessionStorage.getItem(c);
		return null !== n ? JSON.parse(n) : {};
	} catch {
		return {};
	}
};
var s = (t, n) => {
	try {
		t.sessionStorage.setItem(c, JSON.stringify(n));
	} catch {
		return;
	}
};
var l = (t) => {
	const n = {};
	return t.location.search.slice(1).split("&").map(((t) => t.split("="))).map((([t, n]) => {
		try {
			return [decodeURIComponent(t), decodeURIComponent(n)];
		} catch {
			return ["", ""];
		}
	})).filter((([t]) => i(t, r))).map((([t, n]) => [t.slice(r.length), n])).forEach((([t, e]) => {
		n[t] = e;
	})), n;
};
var i = (t, n) => t.substr(0, n.length) === n;
var r = "ionic:";
var c = "ionic-persist-config";
var u;
(function(t) {
	t.OFF = "OFF", t.ERROR = "ERROR", t.WARN = "WARN", t.DEBUG = "DEBUG";
})(u || (u = {}));
var f = {
	[u.OFF]: 0,
	[u.ERROR]: 1,
	[u.WARN]: 2,
	[u.DEBUG]: 3
};
var a = (t) => {
	return f[String(e.get("logLevel", u.WARN)).toUpperCase()] >= f[t];
};
var d = (t, ...n) => {
	if (a(u.WARN)) return console.warn(`[Ionic Warning]: ${t}`, ...n);
};
var h = (t, ...n) => {
	if (a(u.ERROR)) return console.error(`[Ionic Error]: ${t}`, ...n);
};
var v = (t, ...n) => console.error(`<${t.tagName.toLowerCase()}> must be used inside ${n.join(" or ")}.`);
var p = { isBrowser: !0 };
var b = ((t) => (t.Undefined = "undefined", t.Null = "null", t.String = "string", t.Number = "number", t.SpecialNumber = "number", t.Boolean = "boolean", t.BigInt = "bigint", t))(b || {});
var $ = ((t) => (t.Array = "array", t.Date = "date", t.Map = "map", t.Object = "object", t.RegularExpression = "regexp", t.Set = "set", t.Channel = "channel", t.Symbol = "symbol", t))($ || {});
var g = "type";
var m = "value";
var y = "serialized:";
function w(t, n, e) {
	const o = "undefined" != typeof HTMLElement ? HTMLElement.prototype : null;
	for (; t && t !== o;) {
		const o = Object.getOwnPropertyDescriptor(t, n);
		if (o && (!e || o.get)) return o;
		t = Object.getPrototypeOf(t);
	}
}
var j;
var O = (t, n) => {
	var e;
	Object.entries(null != (e = n.o.t) ? e : {}).map((([e, [o]]) => {
		if (31 & o || 32 & o) {
			const o = t[e], s = w(Object.getPrototypeOf(t), e, !0) || Object.getOwnPropertyDescriptor(t, e);
			s && Object.defineProperty(t, e, {
				get() {
					return s.get.call(this);
				},
				set(t) {
					s.set.call(this, t);
				},
				configurable: !0,
				enumerable: !0
			}), n.l.has(e) ? t[e] = n.l.get(e) : void 0 !== o && (t[e] = o);
		}
	}));
};
var S = (t) => {
	if (t.__stencil__getHostRef) return t.__stencil__getHostRef();
};
var N = (t, n) => n in t;
var x = (t, n) => (0, console.error)(t, n);
var E = /* @__PURE__ */ new Map();
var k = [];
var C = "s-id";
var M = "sty-id";
var I = "c-id";
var T = "http://www.w3.org/1999/xlink";
var L = "undefined" != typeof window ? window : {};
var A = L.HTMLElement || class {};
var R = {
	i: 0,
	u: "",
	jmp: (t) => t(),
	raf: (t) => requestAnimationFrame(t),
	ael: (t, n, e, o) => t.addEventListener(n, e, o),
	rel: (t, n, e, o) => t.removeEventListener(n, e, o),
	ce: (t, n) => new CustomEvent(t, n)
};
var B = (() => {
	var t;
	let n = !1;
	try {
		null == (t = L.document) || t.addEventListener("e", null, Object.defineProperty({}, "passive", { get() {
			n = !0;
		} }));
	} catch (t) {}
	return n;
})();
var _ = (() => {
	try {
		return !!L.document.adoptedStyleSheets && (new CSSStyleSheet(), "function" == typeof new CSSStyleSheet().replaceSync);
	} catch (t) {}
	return !1;
})();
var F = !!_ && (() => !!L.document && Object.getOwnPropertyDescriptor(L.document.adoptedStyleSheets, "length").writable)();
var U = !1;
var D = [];
var H = [];
var W = () => {
	var t;
	return (null == (t = L.document) ? void 0 : t.hidden) ? setTimeout(q, 16) : R.raf(q);
};
var V = (t, n) => (e) => {
	t.push(e), U || (U = !0, n && 4 & R.i ? z(q) : W());
};
var P = (t) => {
	for (let n = 0; n < t.length; n++) try {
		t[n](performance.now());
	} catch (t) {
		x(t);
	}
	t.length = 0;
};
var q = () => {
	P(D), P(H), (U = D.length > 0) && W();
};
var z = (t) => Promise.resolve(void 0).then(t);
var J = V(D, !1);
var Y = V(H, !0);
var G = (t) => {
	const n = new URL(t, R.u);
	return n.origin !== L.location.origin ? n.href : n.pathname;
};
function K(t) {
	const n = { mode: "open" };
	n.delegatesFocus = !!(16 & t.i);
	const e = this.attachShadow(n);
	void 0 === j && (j = null), j && (F ? e.adoptedStyleSheets.push(j) : e.adoptedStyleSheets = [...e.adoptedStyleSheets, j]);
}
var Q = (t) => {
	const n = Ct(t, "childNodes");
	t.tagName && t.tagName.includes("-") && t["s-cr"] && "SLOT-FB" !== t.tagName && tt(n, t.tagName).forEach(((t) => {
		1 === t.nodeType && "SLOT-FB" === t.tagName && (t.hidden = !!nt(t, st(t), !1).length);
	}));
	let e = 0;
	for (e = 0; e < n.length; e++) {
		const t = n[e];
		1 === t.nodeType && Ct(t, "childNodes").length && Q(t);
	}
};
var X = (t) => {
	const n = [];
	for (let e = 0; e < t.length; e++) {
		const o = t[e]["s-nr"] || void 0;
		o && o.isConnected && n.push(o);
	}
	return n;
};
function tt(t, n, e) {
	let o, s = 0, l = [];
	for (; s < t.length; s++) {
		if (o = t[s], o["s-sr"] && (!n || o["s-hn"] === n) && (void 0 === e || st(o) === e) && (l.push(o), void 0 !== e)) return l;
		if (l = [...l, ...tt(Ct(o, "childNodes"), n, e)], void 0 !== e && l.length) return l;
	}
	return l;
}
var nt = (t, n, e = !0) => {
	const o = [];
	(e && t["s-sr"] || !t["s-sr"]) && o.push(t);
	let s = t;
	for (; s = s.nextSibling;) st(s) !== n || !e && s["s-sr"] || o.push(s);
	return o;
};
var et = (t, n) => 1 === t.nodeType ? null === t.getAttribute("slot") && "" === n || t.getAttribute("slot") === n : t["s-sn"] === n || "" === n;
var ot = (t, n, e, o) => {
	if (t["s-ol"] && t["s-ol"].isConnected) return;
	const s = document.createTextNode("");
	if (s["s-nr"] = t, !n["s-cr"] || !n["s-cr"].parentNode) return;
	const l = n["s-cr"].parentNode, i = Ct(l, e ? "prepend" : "appendChild");
	if (void 0 !== o) {
		s["s-oo"] = o;
		const t = Ct(l, "childNodes"), n = [s];
		t.forEach(((t) => {
			t["s-nr"] && n.push(t);
		})), n.sort(((t, n) => !t["s-oo"] || t["s-oo"] < (n["s-oo"] || 0) ? -1 : !n["s-oo"] || n["s-oo"] < t["s-oo"] ? 1 : 0)), n.forEach(((t) => i.call(l, t)));
	} else i.call(l, s);
	t["s-ol"] = s, t["s-sh"] = n["s-hn"];
};
var st = (t) => "string" == typeof t["s-sn"] ? t["s-sn"] : 1 === t.nodeType && t.getAttribute("slot") || void 0;
function lt(t) {
	if (t.assignedElements || t.assignedNodes || !t["s-sr"]) return;
	const n = (n) => function(t) {
		const e = [], o = this["s-sn"];
		null != t && t.flatten && console.error("\n          Flattening is not supported for Stencil non-shadow slots.\n          You can use `.childNodes` to nested slot fallback content.\n          If you have a particular use case, please open an issue on the Stencil repo.\n        ");
		const s = this["s-cr"].parentElement;
		return (s.__childNodes ? s.childNodes : X(s.childNodes)).forEach(((t) => {
			o === st(t) && e.push(t);
		})), n ? e.filter(((t) => 1 === t.nodeType)) : e;
	}.bind(t);
	t.assignedElements = n(!0), t.assignedNodes = n(!1);
}
function it(t) {
	t.dispatchEvent(new CustomEvent("slotchange", {
		bubbles: !1,
		cancelable: !1,
		composed: !1
	}));
}
function rt(t, n) {
	var e;
	if (!(n = n || (null == (e = t["s-ol"]) ? void 0 : e.parentElement))) return {
		slotNode: null,
		slotName: ""
	};
	const o = t["s-sn"] = st(t) || "";
	return {
		slotNode: tt(Ct(n, "childNodes"), n.tagName, o)[0],
		slotName: o
	};
}
var ct = (t) => {
	if (t.__cloneNode) return;
	const n = t.__cloneNode = t.cloneNode;
	t.cloneNode = function(t) {
		const e = this.shadowRoot && true, o = n.call(this, !!e && t);
		if (!e && t) {
			let t, n, e = 0;
			const s = [
				"s-id",
				"s-cr",
				"s-lr",
				"s-rc",
				"s-sc",
				"s-p",
				"s-cn",
				"s-sr",
				"s-sn",
				"s-hn",
				"s-ol",
				"s-nr",
				"s-si",
				"s-rf",
				"s-scs"
			], l = this.__childNodes || this.childNodes;
			for (; e < l.length; e++) t = l[e]["s-nr"], n = s.every(((t) => !l[e][t])), t && (o.__appendChild ? o.__appendChild(t.cloneNode(!0)) : o.appendChild(t.cloneNode(!0))), n && o.appendChild(l[e].cloneNode(!0));
		}
		return o;
	};
};
var ut = (t) => {
	t.__appendChild || (t.__appendChild = t.appendChild, t.appendChild = function(t) {
		const { slotName: n, slotNode: e } = rt(t, this);
		if (e) {
			ot(t, e);
			const o = nt(e, n), s = o[o.length - 1], l = o.every(((t) => t["s-sr"])), r = Ct(Ct(s, "parentNode"), "insertBefore")(t, s.nextSibling);
			return it(e), l && Q(this), r;
		}
		return this.__appendChild(t);
	});
};
var ft = (t) => {
	t.__removeChild || (t.__removeChild = t.removeChild, t.removeChild = function(t) {
		return t && void 0 !== t["s-sn"] && tt(this.__childNodes || this.childNodes, this.tagName, t["s-sn"])[0] && t.isConnected ? (t.remove(), void Q(this)) : this.__removeChild(t);
	});
};
var at = (t) => {
	t.__prepend || (t.__prepend = t.prepend, t.prepend = function(...n) {
		n.forEach(((n) => {
			"string" == typeof n && (n = this.ownerDocument.createTextNode(n));
			const e = (n["s-sn"] = st(n)) || "", o = tt(Ct(this, "childNodes"), this.tagName, e)[0];
			if (o) {
				ot(n, o, !0);
				const t = nt(o, e)[0], l = Ct(Ct(t, "parentNode"), "insertBefore")(n, Ct(t, "nextSibling"));
				return it(o), l;
			}
			return 1 === n.nodeType && n.getAttribute("slot") && (n.hidden = !0), t.__prepend.call(this, n);
		}));
	});
};
var dt = (t) => {
	t.__append || (t.__append = t.append, t.append = function(...t) {
		t.forEach(((t) => {
			"string" == typeof t && (t = this.ownerDocument.createTextNode(t)), this.appendChild(t);
		}));
	});
};
var ht = (t) => {
	if (t.__insertAdjacentHTML) return;
	const n = t.insertAdjacentHTML;
	t.insertAdjacentHTML = function(t, e) {
		if ("afterbegin" !== t && "beforeend" !== t) return n.call(this, t, e);
		const o = this.ownerDocument.createElement("_");
		let s;
		if (o.innerHTML = e, "afterbegin" === t) for (; s = o.firstChild;) this.prepend(s);
		else if ("beforeend" === t) for (; s = o.firstChild;) this.append(s);
	};
};
var vt = (t) => {
	if (t.__insertAdjacentText) return;
	const n = t.__insertAdjacentText = t.insertAdjacentText;
	t.insertAdjacentText = function(t, e) {
		"afterbegin" === t ? this.prepend(this.ownerDocument.createTextNode(String(e))) : "beforeend" === t ? this.append(this.ownerDocument.createTextNode(String(e))) : n.call(this, t, e);
	};
};
var pt = (t) => {
	t.__insertBefore || t.__insertBefore || (t.__insertBefore = t.insertBefore, t.insertBefore = function(t, n) {
		const { slotName: e, slotNode: o } = rt(t, this);
		if (o) {
			if (null === n) return this.appendChild(t), t;
			if ((this.__childNodes ? this.childNodes : X(this.childNodes)).includes(n)) {
				if (e !== n["s-sn"]) this.appendChild(t);
				else {
					ot(t, o);
					Ct(Ct(n, "parentNode"), "insertBefore")(t, n), it(o);
				}
				return t;
			}
		}
		const s = null == n ? void 0 : n.__parentNode;
		return s && !this.isSameNode(s) ? this.appendChild(t) : this.__insertBefore(t, n);
	});
};
var bt = (t) => {
	if (t.__insertAdjacentElement) return;
	const n = t.insertAdjacentElement;
	t.insertAdjacentElement = function(t, e) {
		return "afterbegin" !== t && "beforeend" !== t ? n.call(this, t, e) : "afterbegin" === t ? (this.prepend(e), e) : "beforeend" === t ? (this.append(e), e) : e;
	};
};
var $t = (t) => {
	kt("textContent", t), Object.defineProperty(t, "textContent", {
		get: function() {
			let t = "";
			return (this.__childNodes ? this.childNodes : X(this.childNodes)).forEach(((n) => t += n.textContent || "")), t;
		},
		set: function(t) {
			mt(this), null != t && "" !== t && this.append(this.ownerDocument.createTextNode(String(t)));
		}
	});
};
var gt = (t) => {
	if (!globalThis.HTMLElement) return;
	const n = (n, e, o) => {
		var s;
		const l = null == (s = Object.getOwnPropertyDescriptor(n, e)) ? void 0 : s.get;
		l && Object.defineProperty(t, e, {
			get: l,
			set: function(t) {
				mt(this), Array.from(Ct(this, "childNodes")).forEach(((t) => {
					t["s-cn"] || t["s-nr"] || t["s-hn"] === this.tagName || t.remove();
				})), o(this, null != t ? t : "");
			}
		});
	};
	n(Element.prototype, "innerHTML", ((t, n) => t.insertAdjacentHTML("beforeend", n))), n(HTMLElement.prototype, "innerText", ((t, n) => t.append(n)));
};
var mt = (t) => {
	(t.__childNodes ? t.childNodes : X(t.childNodes)).forEach(((t) => {
		t["s-ol"] && t["s-ol"].remove(), t.remove();
	}));
};
var yt = (t) => {
	class n extends Array {
		item(t) {
			return this[t];
		}
	}
	kt("children", t), Object.defineProperty(t, "children", { get() {
		return this.childNodes.filter(((t) => 1 === t.nodeType));
	} }), Object.defineProperty(t, "childElementCount", { get() {
		return this.children.length;
	} }), kt("firstChild", t), Object.defineProperty(t, "firstChild", { get() {
		return this.childNodes[0] || null;
	} }), kt("lastChild", t), Object.defineProperty(t, "lastChild", { get() {
		return this.childNodes[this.childNodes.length - 1] || null;
	} }), kt("childNodes", t), Object.defineProperty(t, "childNodes", { get() {
		const t = new n();
		return t.push(...X(this.__childNodes)), t;
	} });
};
var wt = (t) => {
	t && !t.__nextSibling && (kt("nextSibling", t), Object.defineProperty(t, "nextSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.childNodes, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e + 1] || null : this.__nextSibling;
	} }));
};
var jt = (t) => {
	t && !t.__nextElementSibling && (kt("nextElementSibling", t), Object.defineProperty(t, "nextElementSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.children, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e + 1] || null : this.__nextElementSibling;
	} }));
};
var Ot = (t) => {
	t && !t.__previousSibling && (kt("previousSibling", t), Object.defineProperty(t, "previousSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.childNodes, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e - 1] || null : this.__previousSibling;
	} }));
};
var St = (t) => {
	t && !t.__previousElementSibling && (kt("previousElementSibling", t), Object.defineProperty(t, "previousElementSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.children, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e - 1] || null : this.__previousElementSibling;
	} }));
};
var Nt = (t) => {
	t && !t.__parentNode && (kt("parentNode", t), Object.defineProperty(t, "parentNode", {
		get: function() {
			var t;
			return (null == (t = this["s-ol"]) ? void 0 : t.parentNode) || this.__parentNode;
		},
		set: function(t) {
			this.__parentNode = t;
		}
	}));
};
var xt = [
	"children",
	"nextElementSibling",
	"previousElementSibling"
];
var Et = [
	"childNodes",
	"firstChild",
	"lastChild",
	"nextSibling",
	"previousSibling",
	"textContent",
	"parentNode"
];
function kt(t, n) {
	if (!globalThis.Node || !globalThis.Element) return;
	let e;
	xt.includes(t) ? e = Object.getOwnPropertyDescriptor(Element.prototype, t) : Et.includes(t) && (e = Object.getOwnPropertyDescriptor(Node.prototype, t)), e || (e = Object.getOwnPropertyDescriptor(n, t)), e && Object.defineProperty(n, "__" + t, e);
}
function Ct(t, n) {
	if ("__" + n in t) {
		const e = t["__" + n];
		return "function" != typeof e ? e : e.bind(t);
	}
	return "function" != typeof t[n] ? t[n] : t[n].bind(t);
}
var Mt = /* @__PURE__ */ new WeakMap();
var It = (t, n, e) => {
	let o = E.get(t);
	_ && e ? (o = o || new CSSStyleSheet(), "string" == typeof o ? o = n : o.replaceSync(n)) : o = n, E.set(t, o);
};
var Tt = (t, n, e) => {
	var o, s, l;
	const i = Lt(n, e), r = E.get(i);
	if (!L.document) return i;
	if (t = 11 === t.nodeType ? t : L.document, r) if ("string" == typeof r) {
		let e, l = Mt.get(t = t.head || t);
		if (l || Mt.set(t, l = /* @__PURE__ */ new Set()), t.querySelector(`[${M}="${i}"]`)) l.add(i);
		else if (!l.has(i)) {
			e = L.document.createElement("style"), e.textContent = r;
			const c = null != (o = R.h) ? o : function() {
				var t, n, e;
				return null != (e = null == (n = null == (t = L.document.head) ? void 0 : t.querySelector("meta[name=\"csp-nonce\"]")) ? void 0 : n.getAttribute("content")) ? e : void 0;
			}();
			if (null != c && e.setAttribute("nonce", c), !(1 & n.i)) if ("HEAD" === t.nodeName) {
				const n = t.querySelectorAll("link[rel=preconnect]"), o = n.length > 0 ? n[n.length - 1].nextSibling : t.querySelector("style");
				t.insertBefore(e, (null == o ? void 0 : o.parentNode) === t ? o : null);
			} else if ("host" in t) if (_) {
				const n = new (null != (s = t.defaultView) ? s : t.ownerDocument.defaultView).CSSStyleSheet();
				n.replaceSync(r), F ? t.adoptedStyleSheets.unshift(n) : t.adoptedStyleSheets = [n, ...t.adoptedStyleSheets];
			} else {
				const n = t.querySelector("style");
				n ? n.textContent = r + n.textContent : t.prepend(e);
			}
			else t.append(e);
			1 & n.i && t.insertBefore(e, null), 4 & n.i && (e.textContent += "slot-fb{display:contents}slot-fb[hidden]{display:none}"), l && l.add(i);
		}
	} else {
		let n = Mt.get(t);
		if (n || Mt.set(t, n = /* @__PURE__ */ new Set()), !n.has(i)) {
			const e = null != (l = t.defaultView) ? l : t.ownerDocument.defaultView;
			let o;
			if (r.constructor === e.CSSStyleSheet) o = r;
			else {
				o = new e.CSSStyleSheet();
				for (let t = 0; t < r.cssRules.length; t++) o.insertRule(r.cssRules[t].cssText, t);
			}
			if (F ? t.adoptedStyleSheets.push(o) : t.adoptedStyleSheets = [...t.adoptedStyleSheets, o], n.add(i), "host" in t) {
				const n = t.querySelector(`[${M}="${i}"]`);
				n && Y((() => n.remove()));
			}
		}
	}
	return i;
};
var Lt = (t, n) => "sc-" + (n && 32 & t.i ? t.v + "-" + n : t.v);
var At = (t) => "object" == (t = typeof t) || "function" === t;
var Rt = (t, n, ...e) => {
	let o = null, s = null, l = null, i = !1, r = !1;
	const c = [], u = (n) => {
		for (let e = 0; e < n.length; e++) if (o = n[e], Array.isArray(o)) u(o);
		else if (null != o && "boolean" != typeof o) {
			if (i = "function" != typeof t && !At(o)) o = String(o);
			else if ("function" != typeof t && void 0 === o.i) {
				x("Invalid vNode child");
				continue;
			}
			i && r ? c[c.length - 1].p += o : c.push(i ? Bt(null, o) : o), r = i;
		}
	};
	if (u(e), n) {
		n.key && (s = n.key), n.name && (l = n.name);
		{
			const t = n.className || n.class;
			t && (n.class = "object" != typeof t ? t : Object.keys(t).filter(((n) => t[n])).join(" "));
		}
	}
	if ("function" == typeof t) return t(null === n ? {} : n, c, Ft);
	const f = Bt(t, null);
	return f.$ = n, c.length > 0 && (f.j = c), f.O = s, f.S = l, f;
};
var Bt = (t, n) => ({
	i: 0,
	N: t,
	p: null != n ? n : null,
	k: null,
	j: null,
	$: null,
	O: null,
	S: null
});
var _t = {};
var Ft = {
	forEach: (t, n) => t.map(Ut).forEach(n),
	map: (t, n) => t.map(Ut).map(n).map(Dt)
};
var Ut = (t) => ({
	vattrs: t.$,
	vchildren: t.j,
	vkey: t.O,
	vname: t.S,
	vtag: t.N,
	vtext: t.p
});
var Dt = (t) => {
	if ("function" == typeof t.vtag) {
		const n = { ...t.vattrs };
		return t.vkey && (n.key = t.vkey), t.vname && (n.name = t.vname), Rt(t.vtag, n, ...t.vchildren || []);
	}
	const n = Bt(t.vtag, t.vtext);
	return n.$ = t.vattrs, n.j = t.vchildren, n.O = t.vkey, n.S = t.vname, n;
};
var Ht = (t, n, e, o, s, l, i, r = []) => {
	let c, u, f, a;
	const d = s["s-sc"];
	if (1 === l.nodeType) {
		if (c = l.getAttribute(I), c && l !== s && (u = c.split("."), u[0] === i || "0" === u[0])) {
			f = Vt({
				i: 0,
				C: u[0],
				M: u[1],
				I: u[2],
				T: u[3],
				N: l.tagName.toLowerCase(),
				k: l,
				$: { class: l.className || "" }
			}), n.push(f), l.removeAttribute(I), t.j || (t.j = []), d && u[0] === i && (l["s-si"] = d, f.$.class += " " + d);
			const s = f.k.getAttribute("s-sn");
			"string" == typeof s && ("slot-fb" === f.N && (Pt(s, u[2], f, l, t, n, e, o, r), d && l.classList.add(d)), f.k["s-sn"] = s, f.k.removeAttribute("s-sn")), void 0 !== f.T && (t.j[f.T] = f), t = f, o && "0" === f.I && (o[f.T] = f.k);
		}
		if (l.shadowRoot) for (a = l.shadowRoot.childNodes.length - 1; a >= 0; a--) Ht(t, n, e, o, s, l.shadowRoot.childNodes[a], i, r);
		const h = l.__childNodes || l.childNodes;
		for (a = h.length - 1; a >= 0; a--) Ht(t, n, e, o, s, h[a], i, r);
	} else if (8 === l.nodeType) u = l.nodeValue.split("."), (u[1] === i || "0" === u[1]) && (c = u[0], f = Vt({
		C: u[1],
		M: u[2],
		I: u[3],
		T: u[4] || "0",
		k: l,
		$: null,
		j: null,
		O: null,
		S: null,
		N: null,
		p: null
	}), "t" === c ? (f.k = zt(l, 3), f.k && 3 === f.k.nodeType && (f.p = f.k.textContent, n.push(f), l.remove(), i === f.C && (t.j || (t.j = []), t.j[f.T] = f), o && "0" === f.I && (o[f.T] = f.k))) : "c" === c ? (f.k = zt(l, 8), f.k && 8 === f.k.nodeType && (n.push(f), l.remove())) : f.C === i && ("s" === c ? Pt(l["s-sn"] = u[5] || "", u[2], f, l, t, n, e, o, r) : "r" === c && (o ? l.remove() : (s["s-cr"] = l, l["s-cn"] = !0))));
	else if (t && "style" === t.N) {
		const n = Bt(null, l.textContent);
		n.k = l, n.T = "0", t.j = [n];
	}
	return t;
};
var Wt = (t, n) => {
	if (1 === t.nodeType) {
		const e = t[C] || t.getAttribute(C);
		e && n.set(e, t);
		let o = 0;
		if (t.shadowRoot) for (; o < t.shadowRoot.childNodes.length; o++) Wt(t.shadowRoot.childNodes[o], n);
		const s = t.__childNodes || t.childNodes;
		for (o = 0; o < s.length; o++) Wt(s[o], n);
	} else if (8 === t.nodeType) {
		const e = t.nodeValue.split(".");
		"o" === e[0] && (n.set(e[1] + "." + e[2], t), t.nodeValue = "", t["s-en"] = e[3]);
	}
};
var Vt = (t) => ({
	i: 0,
	C: null,
	M: null,
	I: null,
	T: "0",
	k: null,
	$: null,
	j: null,
	O: null,
	S: null,
	N: null,
	p: null,
	...t
});
function Pt(t, n, e, o, s, l, i, r, c) {
	o["s-sr"] = !0, e.S = t || null, e.N = "slot";
	const u = (null == s ? void 0 : s.k) ? s.k["s-id"] || s.k.getAttribute("s-id") : "";
	if (r && L.document) {
		const l = e.k = L.document.createElement(e.N);
		e.S && e.k.setAttribute("name", t), s.k.shadowRoot && u && u !== e.C ? Ct(s.k, "insertBefore")(l, Ct(s.k, "children")[0]) : Ct(Ct(o, "parentNode"), "insertBefore")(l, o), qt(c, n, t, o, e.C), o.remove(), "0" === e.I && (r[e.T] = e.k);
	} else {
		const l = e.k, i = u && u !== e.C && s.k.shadowRoot;
		qt(c, n, t, o, i ? u : e.C), lt(o), i && s.k.insertBefore(l, s.k.children[0]);
	}
	l.push(e), i.push(e), s.j || (s.j = []), s.j[e.T] = e;
}
var qt = (t, n, e, o, s) => {
	var l, i;
	let r = o.nextSibling;
	if (t[n] = t[n] || [], r && !(null == (l = r.nodeValue) ? void 0 : l.startsWith("s."))) do
		!r || (r.getAttribute && r.getAttribute("slot") || r["s-sn"]) !== e && ("" !== e || r["s-sn"] || r.getAttribute && r.getAttribute("slot") || 8 !== r.nodeType && 3 !== r.nodeType) || (r["s-sn"] = e, t[n].push({
			slot: o,
			node: r,
			hostId: s
		})), r = null == r ? void 0 : r.nextSibling;
	while (r && !(null == (i = r.nodeValue) ? void 0 : i.startsWith("s.")));
};
var zt = (t, n) => {
	let e = t;
	do
		e = e.nextSibling;
	while (e && (e.nodeType !== n || !e.nodeValue));
	return e;
};
var Jt = (t) => {
	k.length = 0, k.push(t);
};
var Yt = (t) => {
	var n;
	return null == (n = S(t)) ? void 0 : n.L;
};
var Gt = (t) => {
	if (!t) return;
	const n = Object.keys(t);
	if (0 === n.length) return;
	let e = !1;
	for (const o of n) {
		if (e) break;
		for (const n of t[o]) if ("string" == typeof n) {
			e = !0;
			break;
		}
	}
	if (!e) return t;
	const o = {};
	for (const e of n) o[e] = t[e].map(((t) => "string" == typeof t ? { [t]: 0 } : t));
	return o;
};
var Zt = class t {
	static fromLocalValue(n) {
		const e = n[g], o = m in n ? n[m] : void 0;
		switch (e) {
			case "string":
			case "boolean": return o;
			case "bigint": return BigInt(o);
			case "undefined": return;
			case "null": return null;
			case "number": return "NaN" === o ? NaN : "-0" === o ? -0 : "Infinity" === o ? 1 / 0 : "-Infinity" === o ? -1 / 0 : o;
			case "array": return o.map(((n) => t.fromLocalValue(n)));
			case "date": return new Date(o);
			case "map":
				const n = /* @__PURE__ */ new Map();
				for (const [e, s] of o) {
					const o = "object" == typeof e && null !== e ? t.fromLocalValue(e) : e, l = t.fromLocalValue(s);
					n.set(o, l);
				}
				return n;
			case "object":
				const s = {};
				for (const [n, e] of o) s[n] = t.fromLocalValue(e);
				return s;
			case "regexp":
				const { pattern: l, flags: i } = o;
				return new RegExp(l, i);
			case "set":
				const r = /* @__PURE__ */ new Set();
				for (const n of o) r.add(t.fromLocalValue(n));
				return r;
			case "symbol": return Symbol(o);
			default: throw new Error(`Unsupported type: ${e}`);
		}
	}
	static fromLocalValueArray(n) {
		return n.map(((n) => t.fromLocalValue(n)));
	}
	static isLocalValueObject(t) {
		if ("object" != typeof t || null === t) return !1;
		if (!t.hasOwnProperty(g)) return !1;
		const n = t[g];
		return !!Object.values({
			...b,
			...$
		}).includes(n) && ("null" === n || "undefined" === n || t.hasOwnProperty(m));
	}
};
var Kt;
var Qt;
var Xt;
var tn = (t, n) => {
	return "string" == typeof t && t.startsWith(y) ? t = "string" == typeof (e = t) && e.startsWith(y) ? Zt.fromLocalValue(JSON.parse(function(t) {
		const n = atob(t), e = new Uint8Array(n.length);
		for (let t = 0; t < n.length; t++) e[t] = n.charCodeAt(t);
		return new TextDecoder().decode(e);
	}(e.slice(11)))) : e : null == t || At(t) ? t : 4 & n ? "false" !== t && ("" === t || !!t) : 2 & n ? "string" == typeof t ? parseFloat(t) : "number" == typeof t ? t : NaN : 1 & n ? String(t) : t;
	var e;
};
var nn = (t, n, e) => {
	const o = t;
	return { emit: (t) => en(o, n, {
		bubbles: !!(4 & e),
		composed: !!(2 & e),
		cancelable: !!(1 & e),
		detail: t
	}) };
};
var en = (t, n, e) => {
	const o = R.ce(n, e);
	return t.dispatchEvent(o), o;
};
var on = (t, n, e, o, s, l, i) => {
	if (e === o) return;
	let r = N(t, n), c = n.toLowerCase();
	if ("class" === n) {
		const n = t.classList, s = un(e);
		let r = un(o);
		if ((t["s-si"] || t["s-sc"]) && i) {
			const e = t["s-sc"] || t["s-si"];
			r.push(e), s.forEach(((t) => {
				t.startsWith(e) && r.push(t);
			})), r = [...new Set(r)].filter(((t) => t)), n.add(...r);
		} else {
			let e = s.filter(((t) => t && !r.includes(t)));
			if (i && !(4 & l)) {
				const n = cn(t);
				e = e.filter(((t) => !n.includes(t)));
			}
			n.remove(...e), n.add(...r.filter(((t) => t && !s.includes(t))));
		}
	} else if ("style" === n) {
		for (const n in e) o && null != o[n] || (n.includes("-") ? t.style.removeProperty(n) : t.style[n] = "");
		for (const n in o) e && o[n] === e[n] || (n.includes("-") ? t.style.setProperty(n, o[n]) : t.style[n] = o[n]);
	} else if ("key" === n);
	else if ("ref" === n) o && In(o, t);
	else if (t.__lookupSetter__(n) || "o" !== n[0] || "n" !== n[1]) {
		if ("a" === n[0] && n.startsWith("attr:")) {
			const e = n.slice(5);
			let s;
			{
				const n = S(t);
				if (n && n.o && n.o.t) {
					const t = n.o.t[e];
					t && t[1] && (s = t[1]);
				}
			}
			s || (s = e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase()), null == o || !1 === o ? !1 === o && "" !== t.getAttribute(s) || t.removeAttribute(s) : t.setAttribute(s, !0 === o ? "" : o);
			return;
		}
		if ("p" === n[0] && n.startsWith("prop:")) {
			const e = n.slice(5);
			try {
				t[e] = o;
			} catch (t) {}
			return;
		}
		{
			const i = At(o);
			if ((r || i && null !== o) && !s) try {
				if (t.tagName.includes("-")) t[n] !== o && (t[n] = o);
				else {
					const s = null == o ? "" : o;
					"list" === n ? r = !1 : null != e && t[n] === s || ("function" == typeof t.__lookupSetter__(n) ? t[n] = s : t.setAttribute(n, s));
				}
			} catch (t) {}
			let u = !1;
			c !== (c = c.replace(/^xlink\:?/, "")) && (n = c, u = !0), null == o || !1 === o ? (!1 !== o || "" === t.getAttribute(n) || 4 & l && !ln(n)) && (u ? t.removeAttributeNS(T, n) : t.removeAttribute(n)) : (!r || 4 & l || s) && !i && 1 === t.nodeType && (o = !0 === o ? "" : o, u ? t.setAttributeNS(T, n, o) : t.setAttribute(n, o));
		}
	} else if (n = "-" === n[2] ? n.slice(3) : N(L, c) ? c.slice(2) : c[2] + n.slice(3), e || o) {
		const s = n.endsWith(fn);
		n = n.replace(an, ""), e && R.rel(t, n, e, s), o && R.ael(t, n, o, s);
	}
};
var sn = /* @__PURE__ */ new Set([
	"draggable",
	"contenteditable",
	"spellcheck"
]);
var ln = (t) => sn.has(t) || t.startsWith("aria-");
var rn = /\s/;
var cn = (n) => {
	var e, o, s;
	const l = S(n);
	if (!(l && 2 & l.i)) return [];
	const i = un(null == (o = null == (e = l.A) ? void 0 : e.$) ? void 0 : o.class);
	return i.push(null != (s = t) ? s : "hydrated"), i;
};
var un = (t) => ("object" == typeof t && t && "baseVal" in t && (t = t.baseVal), t && "string" == typeof t ? t.split(rn) : []);
var fn = "Capture";
var an = new RegExp(fn + "$");
var dn = (t, n, e, o) => {
	const s = 11 === n.k.nodeType && n.k.host ? n.k.host : n.k, l = t && t.$ || {}, i = n.$ || {};
	for (const t of hn(Object.keys(l))) t in i || on(s, t, l[t], void 0, e, n.i, o);
	for (const t of hn(Object.keys(i))) on(s, t, l[t], i[t], e, n.i, o);
};
function hn(t) {
	return t.includes("ref") ? [...t.filter(((t) => "ref" !== t)), "ref"] : t;
}
var vn = !1;
var pn = !1;
var bn = !1;
var $n = !1;
var gn = [];
var mn = [];
var yn = (t, n, e) => {
	var o;
	const s = n.j[e];
	let l, i, r, c = 0;
	if (vn || (bn = !0, "slot" === s.N && (s.i |= s.j ? 2 : 1)), null != s.p) l = s.k = L.document.createTextNode(s.p);
	else if (1 & s.i) l = s.k = L.document.createTextNode(""), dn(null, s, $n);
	else {
		if ($n || ($n = "svg" === s.N), !L.document) throw new Error("You are trying to render a Stencil component in an environment that doesn't support the DOM.");
		if (l = s.k = L.document.createElementNS($n ? "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml", !vn && 2 & s.i ? "slot-fb" : s.N), $n && "foreignObject" === s.N && ($n = !1), dn(null, s, $n), null != (u = Kt) && void 0 !== u && l["s-si"] !== Kt && l.classList.add(l["s-si"] = Kt), s.j) {
			const n = "template" === s.N ? l.content : l;
			for (c = 0; c < s.j.length; ++c) i = yn(t, s, c), i && n.appendChild(i);
		}
		"svg" === s.N ? $n = !1 : "foreignObject" === l.tagName && ($n = !0);
	}
	var u;
	return l["s-hn"] = Xt, 3 & s.i && (l["s-sr"] = !0, l["s-cr"] = Qt, l["s-sn"] = s.S || "", l["s-rf"] = null == (o = s.$) ? void 0 : o.ref, lt(l), r = t && t.j && t.j[e], r && r.N === s.N && t.k && wn(t.k), Ln(Qt, l, n.k, null == t ? void 0 : t.k)), l;
};
var wn = (t) => {
	R.i |= 1;
	const n = t.closest(Xt.toLowerCase());
	if (null != n) {
		const e = Array.from(n.__childNodes || n.childNodes).find(((t) => t["s-cr"])), o = Array.from(t.__childNodes || t.childNodes);
		for (const t of e ? o.reverse() : o) null != t["s-sh"] && (Tn(n, t, null != e ? e : null), t["s-sh"] = void 0, bn = !0);
	}
	R.i &= -2;
};
var jn = (t, n) => {
	R.i |= 1;
	const e = Array.from(t.__childNodes || t.childNodes);
	if (t["s-sr"]) {
		let n = t;
		for (; n = n.nextSibling;) n && n["s-sn"] === t["s-sn"] && n["s-sh"] === Xt && e.push(n);
	}
	for (let t = e.length - 1; t >= 0; t--) {
		const o = e[t];
		o["s-hn"] !== Xt && o["s-ol"] && (Tn(xn(o).parentNode, o, xn(o)), o["s-ol"].remove(), o["s-ol"] = void 0, o["s-sh"] = void 0, bn = !0), n && jn(o, n);
	}
	R.i &= -2;
};
var On = (t, n, e, o, s, l) => {
	let i, r = t["s-cr"] && t["s-cr"].parentNode || t;
	for (r.shadowRoot && r.tagName === Xt && (r = r.shadowRoot), "template" === e.N && (r = r.content); s <= l; ++s) o[s] && (i = yn(null, e, s), i && (o[s].k = i, Tn(r, i, xn(n))));
};
var Sn = (t, n, e) => {
	for (let o = n; o <= e; ++o) {
		const n = t[o];
		if (n) {
			const t = n.k;
			Mn(n), t && (pn = !0, t["s-ol"] ? t["s-ol"].remove() : jn(t, !0), t.remove());
		}
	}
};
var Nn = (t, n, e = !1) => t.N === n.N && ("slot" === t.N ? t.S === n.S : e ? (e && !t.O && n.O && (t.O = n.O), !0) : t.O === n.O);
var xn = (t) => t && t["s-ol"] || t;
var En = (t, n, e = !1) => {
	const o = n.k = t.k, s = t.j, l = n.j, i = n.N, r = n.p;
	let c;
	null == r ? ($n = "svg" === i || "foreignObject" !== i && $n, "slot" !== i || vn || t.S !== n.S && (n.k["s-sn"] = n.S || "", wn(n.k.parentElement)), dn(t, n, $n, e), null !== s && null !== l ? ((t, n, e, o, s = !1) => {
		let l, i, r = 0, c = 0, u = 0, f = 0, a = n.length - 1, d = n[0], h = n[a], v = o.length - 1, p = o[0], b = o[v];
		const $ = "template" === e.N ? t.content : t;
		for (; r <= a && c <= v;) if (null == d) d = n[++r];
		else if (null == h) h = n[--a];
		else if (null == p) p = o[++c];
		else if (null == b) b = o[--v];
		else if (Nn(d, p, s)) En(d, p, s), d = n[++r], p = o[++c];
		else if (Nn(h, b, s)) En(h, b, s), h = n[--a], b = o[--v];
		else if (Nn(d, b, s)) "slot" !== d.N && "slot" !== b.N || jn(d.k.parentNode, !1), En(d, b, s), Tn($, d.k, h.k.nextSibling), d = n[++r], b = o[--v];
		else if (Nn(h, p, s)) "slot" !== d.N && "slot" !== b.N || jn(h.k.parentNode, !1), En(h, p, s), Tn($, h.k, d.k), h = n[--a], p = o[++c];
		else {
			for (u = -1, f = r; f <= a; ++f) if (n[f] && null !== n[f].O && n[f].O === p.O) {
				u = f;
				break;
			}
			u >= 0 ? (i = n[u], i.N !== p.N ? l = yn(n && n[c], e, c) : (En(i, p, s), n[u] = void 0, l = i.k), p = o[++c]) : (l = yn(n && n[c], e, c), p = o[++c]), l && Tn(xn(d.k).parentNode, l, xn(d.k));
		}
		r > a ? On(t, null == o[v + 1] ? null : o[v + 1].k, e, o, c, v) : c > v && Sn(n, r, a);
	})(o, s, n, l, e) : null !== l ? (null !== t.p && (o.textContent = ""), On(o, null, n, l, 0, l.length - 1)) : e || null === s ? e && null !== s && null === l && (n.j = s) : Sn(s, 0, s.length - 1), $n && "svg" === i && ($n = !1)) : (c = o["s-cr"]) ? c.parentNode.textContent = r : t.p !== r && (o.data = r);
};
var kn = [];
var Cn = (t) => {
	let n, e, o;
	const s = t.__childNodes || t.childNodes;
	for (const t of s) {
		if (t["s-sr"] && (n = t["s-cr"]) && n.parentNode) {
			e = n.parentNode.__childNodes || n.parentNode.childNodes;
			const s = t["s-sn"];
			for (o = e.length - 1; o >= 0; o--) if (n = e[o], !n["s-cn"] && !n["s-nr"] && n["s-hn"] !== t["s-hn"] && (!n["s-sh"] || n["s-sh"] !== t["s-hn"] || "" !== s && st(n) === s)) if (et(n, s)) {
				let e = kn.find(((t) => t.R === n));
				pn = !0, n["s-sn"] = n["s-sn"] || s, e ? (e.R["s-sh"] = t["s-hn"], e.B = t) : (n["s-sh"] = t["s-hn"], kn.push({
					B: t,
					R: n
				})), n["s-sr"] && kn.map(((t) => {
					et(t.R, n["s-sn"]) && (e = kn.find(((t) => t.R === n)), e && !t.B && (t.B = e.B));
				}));
			} else kn.some(((t) => t.R === n)) || kn.push({ R: n });
		}
		1 === t.nodeType && Cn(t);
	}
};
var Mn = (t) => {
	t.$ && t.$.ref && gn.push((() => t.$.ref(null))), t.j && t.j.map(Mn);
};
var In = (t, n) => {
	mn.push((() => t(n)));
};
var Tn = (t, n, e, o) => {
	if ("string" == typeof n["s-sn"] && n["s-sr"] && n["s-cr"]) Ln(n["s-cr"], n, t, n.parentElement);
	else if ("string" == typeof n["s-sn"]) {
		11 !== t.getRootNode().nodeType && Nt(n), t.insertBefore(n, e);
		const { slotNode: s } = rt(n);
		return s && !o && it(s), n;
	}
	return (null == t ? void 0 : t.__insertBefore) ? t.__insertBefore(n, e) : null == t ? void 0 : t.insertBefore(n, e);
};
function Ln(t, n, e, o) {
	var s, l;
	let i;
	if (t && "string" == typeof n["s-sn"] && n["s-sr"] && t.parentNode && t.parentNode["s-sc"] && (i = n["s-si"] || t.parentNode["s-sc"])) {
		const t = n["s-sn"], r = n["s-hn"];
		if (null == (s = e.classList) || s.add(i + "-s"), o && (null == (l = o.classList) ? void 0 : l.contains(i + "-s"))) {
			let n = (o.__childNodes || o.childNodes)[0], e = !1;
			for (; n;) {
				if (n["s-sn"] !== t && n["s-hn"] === r && n["s-sr"]) {
					e = !0;
					break;
				}
				n = n.nextSibling;
			}
			e || o.classList.remove(i + "-s");
		}
	}
}
var An = (t, n, e = !1) => {
	var o, s, l, i, r;
	const c = t.$hostElement$, u = t.o, f = t.A || Bt(null, null);
	var a;
	const d = (a = n) && a.N === _t ? n : Rt(null, null, n);
	if (Xt = c.tagName, u._ && (d.$ = d.$ || {}, u._.forEach((([t, n]) => {
		d.$[n] = c[t];
	}))), e && d.$) for (const t of Object.keys(d.$)) c.hasAttribute(t) && ![
		"key",
		"ref",
		"style",
		"class"
	].includes(t) && (d.$[t] = c[t]);
	if (d.N = null, d.i |= 4, t.A = d, d.k = f.k = c.shadowRoot || c, Kt = c["s-sc"], vn = !(!(1 & u.i) || 128 & u.i), Qt = c["s-cr"], pn = !1, En(f, d, e), R.i |= 1, bn) {
		Cn(d.k);
		for (const t of kn) {
			const n = t.R;
			if (!n["s-ol"] && L.document) {
				const t = L.document.createTextNode("");
				t["s-nr"] = n, Tn(n.parentNode, n["s-ol"] = t, n, e);
			}
		}
		for (const t of kn) {
			const n = t.R, r = t.B;
			if (1 === n.nodeType && e && (n["s-ih"] = null != (o = n.hidden) && o), r) {
				const t = r.parentNode;
				let o = r.nextSibling;
				if (o && 1 === o.nodeType) {
					let e = null == (s = n["s-ol"]) ? void 0 : s.previousSibling;
					for (; e;) {
						let s = null != (l = e["s-nr"]) ? l : null;
						if (s && s["s-sn"] === n["s-sn"] && t === (s.__parentNode || s.parentNode)) {
							for (s = s.nextSibling; s === n || (null == s ? void 0 : s["s-sr"]);) s = null == s ? void 0 : s.nextSibling;
							if (!s || !s["s-nr"]) {
								o = s;
								break;
							}
						}
						e = e.previousSibling;
					}
				}
				if ((!o && t !== (n.__parentNode || n.parentNode) || (n.__nextSibling || n.nextSibling) !== o) && n !== o) {
					if (Tn(t, n, o, e), 8 === n.nodeType && n.nodeValue.startsWith("s-nt-")) {
						const t = L.document.createTextNode(n.nodeValue.replace(/^s-nt-/, ""));
						t["s-hn"] = n["s-hn"], t["s-sn"] = n["s-sn"], t["s-sh"] = n["s-sh"], t["s-sr"] = n["s-sr"], t["s-ol"] = n["s-ol"], t["s-ol"]["s-nr"] = t, Tn(n.parentNode, t, n, e), n.parentNode.removeChild(n);
					}
					1 === n.nodeType && "SLOT-FB" !== n.tagName && (n.hidden = null != (i = n["s-ih"]) && i);
				}
				n && "function" == typeof r["s-rf"] && r["s-rf"](r);
			} else 1 === n.nodeType && (n.hidden = !0);
		}
	}
	if (pn && Q(d.k), R.i &= -2, kn.length = 0, !vn && !(1 & u.i) && c["s-cr"]) {
		const t = d.k.__childNodes || d.k.childNodes;
		for (const n of t) if (n["s-hn"] !== Xt && !n["s-sh"]) {
			if (e && null == n["s-ih"] && (n["s-ih"] = null != (r = n.hidden) && r), 1 === n.nodeType) n.hidden = !0;
			else if (3 === n.nodeType && n.nodeValue.trim()) {
				const t = L.document.createComment("s-nt-" + n.nodeValue);
				t["s-sn"] = n["s-sn"], Tn(n.parentNode, t, n, e), n.parentNode.removeChild(n);
			}
		}
	}
	Qt = void 0, gn.forEach(((t) => t())), gn.length = 0, mn.forEach(((t) => t())), mn.length = 0;
};
var Rn = (t, n) => {
	if (n && !t.F && n["s-p"]) {
		const e = n["s-p"].push(new Promise(((o) => t.F = () => {
			n["s-p"].splice(e - 1, 1), o();
		})));
	}
};
var Bn = (t, n) => {
	if (t.i |= 16, 4 & t.i) return void (t.i |= 512);
	Rn(t, t.U);
	const e = () => _n(t, n);
	if (!n) return Y(e);
	queueMicrotask((() => {
		e();
	}));
};
var _n = (t, n) => {
	const e = t.$hostElement$, o = e;
	if (!o) throw new Error(`Can't render component <${e.tagName.toLowerCase()} /> with invalid Stencil runtime! Make sure this imported component is compiled with a \`externalRuntime: true\` flag. For more information, please refer to https://stenciljs.com/docs/custom-elements#externalruntime`);
	let s;
	return s = qn(o, n ? "componentWillLoad" : "componentWillUpdate", void 0, e), s = Fn(s, (() => qn(o, "componentWillRender", void 0, e))), Fn(s, (() => Dn(t, o, n)));
};
var Fn = (t, n) => Un(t) ? t.then(n).catch(((t) => {
	console.error(t), n();
})) : n();
var Un = (t) => t instanceof Promise || t && t.then && "function" == typeof t.then;
var Dn = async (t, n, e) => {
	var o;
	const s = t.$hostElement$, l = s["s-rc"];
	e && ((t) => {
		const n = t.o, e = t.$hostElement$, o = n.i, s = Tt(e.shadowRoot ? e.shadowRoot : e.getRootNode(), n, t.L);
		10 & o && (e["s-sc"] = s, e.classList.add(s + "-h"));
	})(t);
	Hn(t, n, s, e), l && (l.map(((t) => t())), s["s-rc"] = void 0);
	{
		const n = null != (o = s["s-p"]) ? o : [], e = () => Wn(t);
		0 === n.length ? e() : (Promise.all(n).then(e).catch(e), t.i |= 4, n.length = 0);
	}
};
var Hn = (t, n, e, o) => {
	try {
		n = n.render && n.render(), t.i &= -17, t.i |= 2, An(t, n, o);
	} catch (n) {
		x(n, t.$hostElement$);
	}
	return null;
};
var Wn = (t) => {
	const n = t.$hostElement$, e = n, o = t.U;
	qn(e, "componentDidRender", void 0, n), 64 & t.i ? qn(e, "componentDidUpdate", void 0, n) : (t.i |= 64, zn(n), qn(e, "componentDidLoad", void 0, n), t.D(n), o || Pn()), t.F && (t.F(), t.F = void 0), 512 & t.i && z((() => Bn(t, !1))), t.i &= -517;
};
var Vn = (t) => {
	var n;
	{
		const e = S(t), o = null == (n = null == e ? void 0 : e.$hostElement$) ? void 0 : n.isConnected;
		return o && 2 == (18 & e.i) && Bn(e, !1), o;
	}
};
var Pn = () => {
	var t;
	z((() => en(L, "appload", { detail: { namespace: "ionic" } }))), null != (t = R.H) && t.size && R.H.clear();
};
var qn = (t, n, e, o) => {
	if (t && t[n]) try {
		return t[n](e);
	} catch (t) {
		x(t, o);
	}
};
var zn = (n) => {
	var e;
	return n.classList.add(null != (e = t) ? e : "hydrated");
};
var Jn = (t, n, e, o) => {
	const s = S(t);
	if (!s) return;
	const l = t, i = s.l.get(n), r = s.i, c = l;
	e = tn(e, o.t[n][0]);
	if (e !== i && !(Number.isNaN(i) && Number.isNaN(e))) {
		if (s.l.set(n, e), o.W) {
			const t = o.W[n];
			t && t.map(((t) => {
				try {
					const [[o, l]] = Object.entries(t);
					(128 & r || 1 & l) && (c ? c[o](e, i, n) : s.V.push((() => {
						s.P[o](e, i, n);
					})));
				} catch (t) {
					x(t, l);
				}
			}));
		}
		if (2 & r) {
			if (c.componentShouldUpdate && !1 === c.componentShouldUpdate(e, i, n) && !(16 & r)) return;
			16 & r || Bn(s, !1);
		}
	}
};
var Yn = (t, n) => {
	var e, o;
	const s = t.prototype;
	{
		t.watchers && !n.W && (n.W = Gt(t.watchers)), t.deserializers && !n.q && (n.q = t.deserializers), t.serializers && !n.J && (n.J = t.serializers);
		const l = Object.entries(null != (e = n.t) ? e : {});
		l.map((([t, [e]]) => {
			if (31 & e || 32 & e) {
				const { get: o, set: l } = w(s, t) || {};
				o && (n.t[t][0] |= 2048), l && (n.t[t][0] |= 4096), Object.defineProperty(s, t, {
					get() {
						return o ? o.apply(this) : (n = t, S(this).l.get(n));
						var n;
					},
					configurable: !0,
					enumerable: !0
				}), Object.defineProperty(s, t, { set(o) {
					const s = S(this);
					if (s) {
						if (l) return void 0 === (32 & e ? this[t] : s.$hostElement$[t]) && s.l.get(t) && (o = s.l.get(t)), l.apply(this, [tn(o, e)]), void Jn(this, t, o = 32 & e ? this[t] : s.$hostElement$[t], n);
						Jn(this, t, o, n);
					}
				} });
			}
		}));
		{
			const e = /* @__PURE__ */ new Map();
			s.attributeChangedCallback = function(t, o, i) {
				R.jmp((() => {
					var r;
					const c = e.get(t), u = S(this);
					if (this.hasOwnProperty(c), s.hasOwnProperty(c) && "number" == typeof this[c] && this[c] == i) return;
					if (null == c) {
						const e = null == u ? void 0 : u.i;
						if (u && e && !(8 & e) && i !== o) {
							const s = this;
							(null == (r = n.W) ? void 0 : r[t])?.forEach(((n) => {
								const [[l, r]] = Object.entries(n);
								null != (null == s ? void 0 : s[l]) && (128 & e || 1 & r) && s[l].call(s, i, o, t);
							}));
						}
						return;
					}
					const f = l.find((([t]) => t === c)), a = f ? f[1][0] : 0, d = 4 & a;
					if (512 & a && 8 & a && !At(this[c]) && (null == (h = this[c]) || !1 === h ? null : !0 === h ? "" : String(h)) === i) return;
					var h;
					const v = d && null === i && void 0 === this[c];
					d && (i = null !== i && "false" !== i);
					const p = Object.getOwnPropertyDescriptor(s, c);
					v || i === this[c] || null == i && null == this[c] || p.get && !p.set || (this[c] = i);
				}));
			}, t.observedAttributes = Array.from(/* @__PURE__ */ new Set([...Object.keys(null != (o = n.W) ? o : {}), ...l.filter((([t, n]) => 31 & n[0])).map((([t, o]) => {
				var s;
				const l = o[1] || t;
				return e.set(l, t), 512 & o[0] && (null == (s = n._) || s.push([t, l])), l;
			}))]));
		}
	}
	return t;
};
var Gn = async (t, n, e) => {
	let o;
	try {
		if (!(32 & n.i) && (n.i |= 32, n.i &= -1025, o = t.constructor, customElements.whenDefined(t.localName).then((() => n.i |= 128)), o && o.style)) {
			let s;
			"string" == typeof o.style ? s = o.style : "string" != typeof o.style && (n.L = ((t) => k.map(((n) => n(t))).find(((t) => !!t)))(t), n.L && (s = o.style[n.L]));
			const l = Lt(e, n.L);
			if (!E.has(l)) It(l, s, !!(1 & e.i));
		}
		const s = n.U, l = () => Bn(n, !0);
		s && s["s-rc"] ? s["s-rc"].push(l) : l();
	} catch (e) {
		x(e, t), n.F && (n.F(), n.F = void 0), !n.D || 1024 & n.i || n.D(t);
	}
};
var Zn = (t) => {
	if (!L.document) return;
	const n = t["s-cr"] = L.document.createComment("");
	n["s-cn"] = !0, Tn(t, n, t.firstChild);
};
var Kn = (t, n) => {
	const e = {
		i: n[0],
		v: n[1]
	};
	try {
		e.t = n[2], e.Y = n[3], e.W = Gt(t.W), e.q = t.q, e.J = t.J, e._ = [], !(1 & e.i) && 256 & e.i ? (ct(o = t.prototype), ut(o), dt(o), at(o), bt(o), ht(o), vt(o), pt(o), $t(o), gt(o), yt(o), ft(o)) : ct(t.prototype), ((t) => {
			if (!L.document) return;
			const n = L.document.querySelectorAll(`[${M}]`);
			let e = 0;
			for (; e < n.length; e++) {
				const o = n[e].getAttribute(M);
				t.some(((t) => {
					const n = "sc-" + t.v;
					return 1 & t.i && (o === n || 32 & t.i && o.startsWith(n + "-"));
				})) && It(o, n[e].innerHTML.replace(/\/\*!@([^\/]+)\*\/[^\{]+\{/g, "$1{"), !0);
			}
		})([e]);
		const s = t.prototype.connectedCallback, l = t.prototype.disconnectedCallback;
		return Object.assign(t.prototype, {
			__hasHostListenerAttached: !1,
			__registerHost() {
				((t, n) => {
					const e = {
						i: 0,
						$hostElement$: t,
						o: n,
						l: /* @__PURE__ */ new Map(),
						G: /* @__PURE__ */ new Map()
					};
					e.Z = new Promise(((t) => e.D = t)), t["s-p"] = [], t["s-rc"] = [];
					const o = e;
					t.__stencil__getHostRef = () => o, 512 & n.i && O(t, e);
				})(this, e);
			},
			connectedCallback() {
				if (!this.__hasHostListenerAttached) {
					const t = S(this);
					if (!t) return;
					Xn(this, t, e.Y), this.__hasHostListenerAttached = !0;
				}
				((t) => {
					if (!(1 & R.i)) {
						const n = S(t);
						if (!n) return;
						const e = n.o;
						if (1 & n.i) Xn(t, n, e.Y), null != n && n.P || (1024 & n.i ? setTimeout((() => Gn(t, n, e)), 1e3) : null != n && n.Z && n.Z.then((() => {})));
						else {
							let o;
							if (n.i |= 1, o = t.getAttribute(C), o) {
								if (1 & e.i) {
									const n = Tt(t.shadowRoot, e, t.getAttribute("s-mode"));
									t.classList.remove(n + "-h", n + "-s");
								} else if (2 & e.i) t["s-sc"] = Lt(e, t.getAttribute("s-mode"));
								((t, n, e, o) => {
									var s, l, i, r;
									const c = t.shadowRoot, u = [], f = [], a = [], d = c ? [] : null, h = Bt(n, null);
									let v;
									h.k = t;
									{
										const n = o.o;
										n && 10 & n.i && t["s-sc"] ? (v = t["s-sc"], t.classList.add(v + "-h")) : t["s-sc"] && delete t["s-sc"];
									}
									!L.document || R.H && R.H.size || Wt(L.document.body, R.H = /* @__PURE__ */ new Map()), t[C] = e, t.removeAttribute(C), o.A = Ht(h, u, f, d, t, t, e, a);
									let p = 0;
									const b = u.length;
									let $;
									for (; p < b; p++) {
										$ = u[p];
										const e = $.C + "." + $.M, o = R.H.get(e), l = $.k;
										if (c) {
											if ((null == (s = $.N) ? void 0 : s.toString().includes("-")) && "slot-fb" !== $.N && !$.k.shadowRoot) {
												const t = S($.k);
												if (t) {
													const n = Lt(t.o, $.k.getAttribute("s-mode")), e = L.document.querySelector(`style[sty-id="${n}"]`);
													e && d.unshift(e.cloneNode(!0));
												}
											}
										} else l["s-hn"] = n.toUpperCase(), "slot" === $.N && (l["s-cr"] = t["s-cr"]);
										"slot" === $.N && ($.S = $.k["s-sn"] || $.k.name || null, $.j ? ($.i |= 2, $.k.childNodes.length || $.j.forEach(((t) => {
											$.k.appendChild(t.k);
										}))) : $.i |= 1), o && o.isConnected && (o.parentElement.shadowRoot && "" === o["s-en"] && o.parentNode.insertBefore(l, o.nextSibling), o.parentNode.removeChild(o), c || (l["s-oo"] = parseInt($.M))), o && !o["s-id"] && R.H.delete(e);
									}
									const g = [], m = a.length;
									let y, w, j, O, N = 0, x = 0;
									for (; N < m; N++) if (y = a[N], y && y.length) for (j = y.length, w = 0; w < j; w++) {
										if (O = y[w], g[O.hostId] || (g[O.hostId] = R.H.get(O.hostId)), !g[O.hostId]) continue;
										const t = g[O.hostId];
										t.shadowRoot && O.node.parentElement !== t && t.insertBefore(O.node, null == (i = null == (l = y[w - 1]) ? void 0 : l.node) ? void 0 : i.nextSibling), t.shadowRoot && c || (O.slot["s-cr"] || (O.slot["s-cr"] = t["s-cr"], O.slot["s-cr"] = !O.slot["s-cr"] && t.shadowRoot ? t : (t.__childNodes || t.childNodes)[0]), ot(O.node, O.slot, !1, O.node["s-oo"] || x), null != (r = O.node.parentElement) && r.shadowRoot && O.node.getAttribute && O.node.getAttribute("slot") && O.node.removeAttribute("slot"), (E = O.node) && void 0 === E.__nextSibling && globalThis.Node && (wt(E), Ot(E), Nt(E), E.nodeType === Node.ELEMENT_NODE && (jt(E), St(E)))), x = (O.node["s-oo"] || x) + 1;
									}
									var E;
									if (v && f.length && f.forEach(((t) => {
										t.k.parentElement.classList.add(v + "-s");
									})), c && !c.childNodes.length) {
										let n = 0;
										const e = d.length;
										if (e) {
											for (; n < e; n++) {
												const t = d[n];
												t && c.appendChild(t);
											}
											Array.from(t.childNodes).forEach(((t) => {
												"string" != typeof t["s-en"] && "string" != typeof t["s-sn"] && (1 === t.nodeType && t.slot && t.hidden ? t.removeAttribute("hidden") : 8 !== t.nodeType || t.nodeValue || t.parentNode.removeChild(t));
											}));
										}
									}
									o.$hostElement$ = t;
								})(t, e.v, o, n);
							}
							o || 12 & e.i && Zn(t);
							{
								let e = t;
								for (; e = e.parentNode || e.host;) if (1 === e.nodeType && e.hasAttribute("s-id") && e["s-p"] || e["s-p"]) {
									Rn(n, n.U = e);
									break;
								}
							}
							e.t && Object.entries(e.t).map((([n, [e]]) => {
								if (31 & e && Object.prototype.hasOwnProperty.call(t, n)) {
									const e = t[n];
									delete t[n], t[n] = e;
								}
							})), Gn(t, n, e);
						}
					}
				})(this), s && s.call(this);
			},
			disconnectedCallback() {
				(async (t) => {
					if (!(1 & R.i)) {
						const n = S(t);
						null != n && n.K && (n.K.map(((t) => t())), n.K = void 0);
					}
					Mt.has(t) && Mt.delete(t), t.shadowRoot && Mt.has(t.shadowRoot) && Mt.delete(t.shadowRoot);
				})(this), l && l.call(this);
			},
			__attachShadow() {
				if (this.shadowRoot) {
					if ("open" !== this.shadowRoot.mode) throw new Error(`Unable to re-use existing shadow root for ${e.v}! Mode is set to ${this.shadowRoot.mode} but Stencil only supports open shadow roots.`);
				} else K.call(this, e);
			}
		}), Object.defineProperty(t, "is", {
			value: e.v,
			configurable: !0
		}), Yn(t, e);
	} catch (n) {
		return x(n), t;
	}
	var o;
};
var Qn = (t, n) => n;
var Xn = (t, n, e) => {
	e && L.document && e.map((([e, o, s]) => {
		const l = ne(L.document, t, e), i = te(n, s), r = ee(e);
		R.ael(l, o, i, r), (n.K = n.K || []).push((() => R.rel(l, o, i, r)));
	}));
};
var te = (t, n) => (e) => {
	try {
		t.$hostElement$[n](e);
	} catch (n) {
		x(n, t.$hostElement$);
	}
};
var ne = (t, n, e) => 4 & e ? t : 8 & e ? L : 16 & e ? t.body : n;
var ee = (t) => B ? {
	passive: !!(1 & t),
	capture: !!(2 & t)
} : !!(2 & t);
function re(t) {
	return t;
}
export { o as _, Kn as a, s as b, Vn as c, _t as d, d as f, nn as g, l as h, Jt as i, Y as l, h as m, G as n, Qn as o, e as p, J as r, Rt as s, A as t, Yt as u, p as v, v as x, re as y };
