import { registerPlugin } from "./@capacitor_core.js";
// node_modules/@capacitor-community/privacy-screen/dist/esm/index.js
var PrivacyScreen = registerPlugin("PrivacyScreen", { web: () => import("./web-bD8c_k9n.js").then((m) => new m.PrivacyScreenWeb()) });
export { PrivacyScreen };
