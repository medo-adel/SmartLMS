import { CapacitorException, WebPlugin, registerPlugin } from "./@capacitor_core.js";
import { BiometryError, isBiometryErrorType } from "./@aparajita_capacitor-biometric-auth.js";
// node_modules/@capacitor/app/dist/esm/index.js
var App = registerPlugin("App", { web: () => import("./web-DKt5Mpuo.js").then((m) => new m.AppWeb()) });
// node_modules/@aparajita/capacitor-biometric-auth/dist/esm/base.js
var BiometricAuthBase = class extends WebPlugin {
	async authenticate(options) {
		try {
			await this.internalAuthenticate(options);
		} catch (error) {
			throw error instanceof CapacitorException && isBiometryErrorType(error.code) ? new BiometryError(error.message, error.code) : error;
		}
	}
	async addResumeListener(listener) {
		return App.addListener("appStateChange", ({ isActive }) => {
			if (isActive) (async () => {
				try {
					listener(await this.checkBiometry());
				} catch (error) {
					console.error(error);
				}
			})();
		});
	}
};
export { BiometricAuthBase as t };
