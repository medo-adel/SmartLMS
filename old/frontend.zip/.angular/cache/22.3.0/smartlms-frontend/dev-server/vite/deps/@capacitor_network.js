import { registerPlugin } from "./@capacitor_core.js";
// node_modules/@capacitor/network/dist/esm/index.js
var Network = registerPlugin("Network", { web: () => import("./web-B4i9-K16.js").then((m) => new m.NetworkWeb()) });
export { Network };
